# 2026-04-28_GOOGLE_ADS_OVERVIEW_PAGE_TEXT_SNAPSHOT

## Captured facts from visible Google Ads Overview page

- Account/store label visible: dresslikemommy.com
- Page: Overview
- View: All campaigns
- Filters:
  - Campaign status: All
  - Ad group status: All
- Date range visible: Custom, Mar 1–28, 2026
- Campaign selector count visible: Campaigns (114)

## Account notice

None of the ads are running. Campaigns and ad groups are paused or removed.

## Visible account metrics

| Metric | Value |
|---|---:|
| Impressions | 0 |
| Clicks | 0 |
| Avg. CPC | $0.00 |
| Cost | $0.00 |

## Visible conversion tracking status

| Status | Count |
|---|---:|
| Tag inactive | 6 |
| Unverified | 0 |
| No recent conversions | 12 |
| Recording conversions | 0 |

## Visible campaign diagnostics

| Campaign | Status/diagnostic |
|---|---|
| USA Cold Traffic Search #2 | Paused; campaign is paused, all ad groups are paused, +1 more issue |
| Remarketing - Cart Abandoners & Checkout Starters | Paused; campaign is paused, 5 out of 5 ads are limited by policy |
| Search - Brand | Paused; campaign is paused |
| Shopping - All Products | Paused; campaign is paused |
| Search - Non-Brand | Paused; campaign is paused |

## Sensitive data handling

Account email and payment-method details visible on the page were intentionally not reproduced.
